#  FURIA ChatBot - Torcida CS:GO

Um chatbot e  feito para os fãs do time de CS:GO da **FURIA**!  
Feito com **React + Vite**, o bot responde perguntas como "quem joga hoje", "estatísticas", "último jogo" e muito mais.

## Funcionalidades

- Interface de chat estilosa e responsiva
- Respostas automáticas para perguntas pré-definidas
- Sistema de mensagens com separação entre usuário e bot
- Pronto para expandir com integração real no futuro!

## 💻 Tecnologias

- [React](https://reactjs.org/)
- [Vite](https://vitejs.dev/)
- CSS-in-JS com `style` inline


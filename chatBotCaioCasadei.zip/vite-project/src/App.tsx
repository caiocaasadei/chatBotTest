import ChatBot from './components/ChatBot'

export default function App() {
  return (
    <div style={styles.page}>
      <header style={styles.header}>
        <img src="/furia-logo.png" alt="FURIA" style={styles.logo} />
        <h1>Fala Fã da FURIA!</h1>
        <p>Converse com o bot e fique por dentro dos jogos, stats e curiosidades!</p>
      </header>

      <ChatBot />

      <footer style={styles.footer}>
        Feito com 💜 por torcedores da FURIA | Não oficial
      </footer>
    </div>
  )
}

const styles = {
  page: {
    fontFamily: 'Arial, sans-serif',
    backgroundColor: '#0f0f0f',
    color: '#fff',
    textAlign: 'center' as const,
    minHeight: '100vh',
    padding: '20px',
  },
  header: {
    marginBottom: '20px',
  },
  logo: {
    width: '80px',
    marginBottom: '10px',
  },
  footer: {
    marginTop: '40px',
    fontSize: '0.8rem',
    color: '#aaa',
  },
}

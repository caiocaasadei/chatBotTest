import React, { useState } from 'react'

type Message = {
  from: 'user' | 'bot'
  text: string
}

const mockResponses: Record<string, string> = {
  'quem joga hoje': 'Hoje a FURIA enfrenta a NAVI às 18h!',
  'último jogo': 'A FURIA venceu a Liquid por 2x1 ontem!',
  'estatísticas': 'KSCERATO: 1.21 rating | arT: 0.98 | yuurih: 1.15',
  'curiosidade': 'Você sabia que a FURIA já venceu 10 Majors no Brasil? (mentira rs)',
  'quiz': '🔍 Pergunta: Qual jogador da FURIA tem mais clutches em 2024?',
}

export default function ChatBot() {
  const [messages, setMessages] = useState<Message[]>([
    { from: 'bot', text: 'Fala, torcedor! Pergunta algo como "quem joga hoje" ou "estatísticas"' },
  ])
  const [input, setInput] = useState<string>('')

  const handleSend = () => {
    if (!input.trim()) return

    const lower = input.toLowerCase()
    const response = mockResponses[lower] || 'Ainda não sei isso, mas logo aprendo! :('

    setMessages(prev => [
      ...prev,
      { from: 'user', text: input },
      { from: 'bot', text: response },
    ])

    setInput('')
  }

  return (
    <div style={styles.container as React.CSSProperties}>
      <div style={styles.chat as React.CSSProperties}>
        {messages.map((msg, i) => (
          <div
            key={i}
            style={{
              ...styles.msg,
              alignSelf: msg.from === 'user' ? 'flex-end' : 'flex-start',
              backgroundColor: msg.from === 'user' ? '#1f1' : '#444',
            } as React.CSSProperties}
          >
            {msg.text}
          </div>
        ))}
      </div>
      <div style={styles.inputArea as React.CSSProperties}>
        <input
          style={styles.input as React.CSSProperties}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="Digite sua pergunta..."
        />
        <button style={styles.button as React.CSSProperties} color="Black" onClick={handleSend}>Enviar</button>
      </div>
    </div>
  )
}

const styles = {
  container: {
    maxWidth: '600px',
    margin: '0 auto',
    backgroundColor: '#222',
    borderRadius: '8px',
    padding: '20px',
  },
  chat: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    minHeight: '300px',
    maxHeight: '400px',
    overflowY: 'auto',
    backgroundColor: '#111',
    padding: '10px',
    borderRadius: '8px',
    marginBottom: '10px',
  },
  msg: {
    padding: '10px 14px',
    borderRadius: '16px',
    maxWidth: '80%',
    color: '#fff',
  },
  inputArea: {
    display: 'flex',
    gap: '10px',
  },
  input: {
    flexGrow: 1,
    padding: '10px',
    borderRadius: '8px',
    border: 'none',
    fontSize: '1rem',
  },
  button: {
    padding: '10px 20px',
    borderRadius: '8px',
    border: 'none',
    backgroundColor: 'black',
    color: '#fff',
    fontWeight: 'bold',
    cursor: 'pointer',
  },
}
